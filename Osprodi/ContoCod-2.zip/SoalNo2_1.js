const readline = require("readline")

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
})




rl.question("", function(nama) 
{
    rl.question("", function(angkanim) 
    {
        var kelasabc      = angkanim < 30 ? "A" :  angkanim < 58 ? "B" : "C";
        var kelasgangenap = angkanim % 2 == 0 ? "B" :  "A";

        console.log(`Halo, namaku ${nama}.`);
        console.log("Pada semester ini aku mendapat kelas " + kelasabc + " dan " + kelasgangenap);

        process.exit();
    })
})