const readline = require("readline")

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
})




rl.question("", function(tahun) 
{
    if(tahun.length < 2)
    {
        var digitahun = "0" + tahun;
    }
    
    rl.question("", function(jumlah) 
    {
        var i;
        for(i = 1; i <= jumlah; i++)
        {
            if(i < 10)
            {
                var angkanim = "00" + i;
            }     
            else if(i < 100)
            {
                var angkanim = "0" + i;
            }       
            else
            {
                var angkanim = i;
            }

            console.log("M05" + digitahun + angkanim); 
                    
        }
        process.exit();
    })
})